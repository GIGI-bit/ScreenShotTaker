﻿

using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Drawing.Imaging;
using System.Net;
using System.Net.Sockets;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.IO;


static void Main() { }
Image TakeScreenShot()
{
    Image screenShot;

    screenShot = new Bitmap(1920, 1200);
    using Graphics graphics = Graphics.FromImage(screenShot);
    Size size = new Size(screenShot.Width, screenShot.Height);
    graphics.CopyFromScreen(0, 0, 0, 0, size);

    return screenShot;
}


var ip = IPAddress.Parse("192.168.1.6");
var port = 25000;
IPEndPoint endPoint = new IPEndPoint(ip, port);
var ser = new UdpClient(endPoint);
while (true)
{

    var message = "";
    var buffer = new byte[1024];
    var result = await ser.ReceiveAsync();
    Console.WriteLine(result.RemoteEndPoint);
    new Task(async () =>
     {
         endPoint = result.RemoteEndPoint;
         while (true)
         {
             Image image = TakeScreenShot();
             byte[] imageByte = null;
             using (MemoryStream ms = new MemoryStream())
             {
                 image.Save(ms, ImageFormat.Png);
                 imageByte = ms.ToArray();
             }
             await Console.Out.WriteLineAsync(imageByte.Length.ToString());
             var temp = imageByte.Chunk(ushort.MaxValue - 29);

             foreach (var item in temp)
             {
                 //await server.SendAsync();
                 await ser.SendAsync(item, item.Length, endPoint);
             
             }
         }

     }).Start();



}


