﻿using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace ClientSreeN
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        IPAddress ip = IPAddress.Parse("192.168.1.6");
        int port = 25000;
        IPEndPoint remoteEP;
        UdpClient  client=null;
        byte[] buffer = new byte[ushort.MaxValue-29];
        BitmapImage image;
            List<byte> list = new List<byte>();
        private async void Start_Click(object sender, RoutedEventArgs e)
        {
                remoteEP = new IPEndPoint(ip, port);
                client = new UdpClient();
                client.Connect(remoteEP);
            int len = 0;
            client.SendAsync(buffer);
            while (true)
            {

                do
                {
                    try
                    {
                        var result = await client.ReceiveAsync();
                        len = result.Buffer.Length;
                        list.AddRange(result.Buffer);


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                   
                } while (buffer.Length == len);
                byteToImg();
                list.Clear();
            }
                
            
        }

        private void byteToImg()
        {
            using (MemoryStream ms=new MemoryStream(list.ToArray()))
            {
                image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.StreamSource = ms;
                image.EndInit();
            }
            img.Source = image;
        }

        private async Task Read()
        {
            
            byteToImg();
            Read();
        }


    }
}